- v1.0.2
	- Removed Yuuka (due to high poly count causing low frame rate)
	- Added Cirno in Ice cube
	- Added Flan
	- Adjusted Inaba hops and hitbox

- v1.0.1:
	- Added Yuuka
	- Added Inaba
	- Added LostWorldFlan